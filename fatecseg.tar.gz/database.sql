-- =======================================================
-- FatecSeg Corp - Script de Criação e População do Banco
-- Disciplina: Desenvolvimento Seguro
-- Objetivo Didático: Demonstração de vulnerabilidade SQLi
-- NOTA: Senhas armazenadas propositalmente em texto puro.
-- =======================================================

CREATE DATABASE IF NOT EXISTS `fatecseg_corp` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `fatecseg_corp`;

-- Estrutura da tabela de usuários
DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nome` VARCHAR(120) NOT NULL,
    `email` VARCHAR(150) NOT NULL UNIQUE,
    `senha` VARCHAR(255) NOT NULL, -- Senhas em texto puro para a demonstração
    `cargo` VARCHAR(100) NOT NULL,
    `criado_em` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- População inicial com 12 usuários corporativos
INSERT INTO `usuarios` (`nome`, `email`, `senha`, `cargo`) VALUES
('Administrador do Sistema', 'admin@fatecseg.local', 'admin123', 'Administrador Geral'),
('Carlos Eduardo Silva', 'carlos.silva@fatecseg.local', 'carlos@2026', 'Diretor de Operações (COO)'),
('Mariana Santos', 'mariana.santos@fatecseg.local', 'mariana#segura', 'Gerente de Segurança da Informação (CISO)'),
('Roberto Almeida', 'roberto.almeida@fatecseg.local', 'roberto@pass', 'Analista SOC Sênior'),
('Fernanda Costa', 'fernanda.costa@fatecseg.local', 'fernanda1234', 'Especialista em Resposta a Incidentes'),
('Lucas Oliveira', 'lucas.oliveira@fatecseg.local', 'lucas#fatec', 'Engenheiro de DevSecOps'),
('Patrícia Souza', 'patricia.souza@fatecseg.local', 'patricia987', 'Auditora de Conformidade e LGPD'),
('Bruno Lima', 'bruno.lima@fatecseg.local', 'bruno@corp26', 'Analista de Inteligência de Ameaças'),
('Juliana Mendes', 'juliana.mendes@fatecseg.local', 'juliana@mendes', 'Coordenadora de Recursos Humanos'),
('Tiago Ferreira', 'tiago.ferreira@fatecseg.local', 'tiago@seg2026', 'Arquiteto de Soluções em Nuvem'),
('Eduardo Ramos', 'eduardo.ramos@fatecseg.local', 'suporte#2026', 'Analista de Suporte Técnico'),
('Beatriz Rocha', 'beatriz.rocha@fatecseg.local', 'financas@fatec', 'Supervisora Financeira');
