<?php
// FatecSeg Corp - Script PHP para criação e população automática do banco de dados
// Pode ser executado via CLI (php setup_db.php) ou navegador (http://localhost/setup_db.php)

require_once __DIR__ . '/config/db.php';

$usuarios = array(
    array('nome' => 'Administrador do Sistema', 'email' => 'admin@fatecseg.local', 'senha' => 'admin123', 'cargo' => 'Administrador Geral'),
    array('nome' => 'Carlos Eduardo Silva', 'email' => 'carlos.silva@fatecseg.local', 'senha' => 'carlos@2026', 'cargo' => 'Diretor de Operações (COO)'),
    array('nome' => 'Mariana Santos', 'email' => 'mariana.santos@fatecseg.local', 'senha' => 'mariana#segura', 'cargo' => 'Gerente de Segurança da Informação (CISO)'),
    array('nome' => 'Roberto Almeida', 'email' => 'roberto.almeida@fatecseg.local', 'senha' => 'roberto@pass', 'cargo' => 'Analista SOC Sênior'),
    array('nome' => 'Fernanda Costa', 'email' => 'fernanda.costa@fatecseg.local', 'senha' => 'fernanda1234', 'cargo' => 'Especialista em Resposta a Incidentes'),
    array('nome' => 'Lucas Oliveira', 'email' => 'lucas.oliveira@fatecseg.local', 'senha' => 'lucas#fatec', 'cargo' => 'Engenheiro de DevSecOps'),
    array('nome' => 'Patrícia Souza', 'email' => 'patricia.souza@fatecseg.local', 'senha' => 'patricia987', 'cargo' => 'Auditora de Conformidade e LGPD'),
    array('nome' => 'Bruno Lima', 'email' => 'bruno.lima@fatecseg.local', 'senha' => 'bruno@corp26', 'cargo' => 'Analista de Inteligência de Ameaças'),
    array('nome' => 'Juliana Mendes', 'email' => 'juliana.mendes@fatecseg.local', 'senha' => 'juliana@mendes', 'cargo' => 'Coordenadora de Recursos Humanos'),
    array('nome' => 'Tiago Ferreira', 'email' => 'tiago.ferreira@fatecseg.local', 'senha' => 'tiago@seg2026', 'cargo' => 'Arquiteto de Soluções em Nuvem'),
    array('nome' => 'Eduardo Ramos', 'email' => 'eduardo.ramos@fatecseg.local', 'senha' => 'suporte#2026', 'cargo' => 'Analista de Suporte Técnico'),
    array('nome' => 'Beatriz Rocha', 'email' => 'beatriz.rocha@fatecseg.local', 'senha' => 'financas@fatec', 'cargo' => 'Supervisora Financeira')
);

$messages = array();
$status = 'info';

// Tenta conexão com servidor MySQL para criar o banco de dados se não existir
if (extension_loaded('mysqli')) {
    $rootConn = @mysqli_connect(DB_HOST, DB_USER, DB_PASS, '', DB_PORT);
    if ($rootConn) {
        $createDbSql = "CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
        if (@mysqli_query($rootConn, $createDbSql)) {
            $messages[] = "[MySQL] Banco de dados '" . DB_NAME . "' verificado/criado com sucesso.";
        }
        @mysqli_close($rootConn);
    }
}

// Conecta ao banco de dados destino
$conn = getDbConnection();

if (!$conn) {
    $messages[] = "[ERRO] Não foi possível conectar ao MySQL nem inicializar SQLite. Verifique as configurações de DB em config/db.php.";
    $status = 'error';
} else {
    // 1. Criar tabela usuarios
    if ($conn instanceof mysqli) {
        $dropSql = "DROP TABLE IF EXISTS `usuarios`";
        mysqli_query($conn, $dropSql);

        $tableSql = "CREATE TABLE `usuarios` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `nome` VARCHAR(120) NOT NULL,
            `email` VARCHAR(150) NOT NULL UNIQUE,
            `senha` VARCHAR(255) NOT NULL,
            `cargo` VARCHAR(100) NOT NULL,
            `criado_em` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        
        if (mysqli_query($conn, $tableSql)) {
            $messages[] = "[MySQL] Tabela 'usuarios' recriada com sucesso.";
            
            $inserted = 0;
            foreach ($usuarios as $u) {
                $nome = mysqli_real_escape_string($conn, $u['nome']);
                $email = mysqli_real_escape_string($conn, $u['email']);
                $senha = mysqli_real_escape_string($conn, $u['senha']); // texto puro no banco
                $cargo = mysqli_real_escape_string($conn, $u['cargo']);
                
                $insertSql = "INSERT INTO `usuarios` (`nome`, `email`, `senha`, `cargo`) VALUES ('$nome', '$email', '$senha', '$cargo')";
                if (mysqli_query($conn, $insertSql)) {
                    $inserted++;
                }
            }
            $messages[] = "[MySQL] $inserted usuários inseridos com sucesso com senhas em texto puro.";
            $status = 'success';
        } else {
            $messages[] = "[MySQL ERRO] Falha ao criar tabela: " . mysqli_error($conn);
            $status = 'error';
        }
    } elseif ($conn instanceof PDO) {
        // SQLite
        $conn->exec("DROP TABLE IF EXISTS usuarios");
        $conn->exec("CREATE TABLE usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            senha TEXT NOT NULL,
            cargo TEXT NOT NULL,
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
        )");
        $messages[] = "[SQLite] Tabela 'usuarios' recriada no arquivo data/fatecseg.sqlite.";

        $inserted = 0;
        foreach ($usuarios as $u) {
            $stmt = $conn->prepare("INSERT INTO usuarios (nome, email, senha, cargo) VALUES (:nome, :email, :senha, :cargo)");
            if ($stmt->execute(array(
                ':nome' => $u['nome'],
                ':email' => $u['email'],
                ':senha' => $u['senha'],
                ':cargo' => $u['cargo']
            ))) {
                $inserted++;
            }
        }
        $messages[] = "[SQLite] $inserted usuários inseridos com sucesso com senhas em texto puro.";
        $status = 'success';
    }
}

// Se executado via CLI
if (php_sapi_name() === 'cli') {
    echo "====================================================\n";
    echo " FatecSeg Corp - Inicialização do Banco de Dados\n";
    echo "====================================================\n";
    foreach ($messages as $msg) {
        echo $msg . "\n";
    }
    echo "Status final: " . strtoupper($status) . "\n";
    exit(0);
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <title>Setup do Banco | FatecSeg Corp</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body style="background: #f0f4f9; display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 20px;">
    <div style="background: #fff; max-width: 650px; width: 100%; border-radius: 8px; box-shadow: 0 10px 25px rgba(0,0,0,0.08); padding: 35px; border: 1px solid #e1e7f0;">
        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 20px;">
            <span class="brand-mark" style="width: 36px; height: 36px; font-size: 14px;">FS</span>
            <div>
                <strong style="font-size: 18px; color: #0d2038;">FatecSeg Corp</strong>
                <div style="font-size: 12px; color: #63758c;">Inicialização & População de Dados</div>
            </div>
        </div>

        <h2 style="color: #11263f; margin-bottom: 15px;">Status da Instalação do Banco</h2>

        <div style="background: #172133; color: #9df0b8; padding: 18px; border-radius: 6px; font-family: monospace; font-size: 13px; line-height: 1.6; margin-bottom: 25px;">
            <?php foreach ($messages as $msg): ?>
                <div>&gt; <?php echo htmlspecialchars($msg); ?></div>
            <?php endforeach; ?>
        </div>

        <h3 style="font-size: 16px; margin-bottom: 10px; color: #1e3a5f;">Usuários de Demonstração (<?php echo count($usuarios); ?> contas):</h3>
        <div style="max-height: 220px; overflow-y: auto; border: 1px solid #e1e7f0; border-radius: 4px; margin-bottom: 25px;">
            <table style="width: 100%; border-collapse: collapse; font-size: 12px; text-align: left;">
                <thead style="background: #f5f8fc; color: #41526a;">
                    <tr>
                        <th style="padding: 8px 12px; border-bottom: 1px solid #e1e7f0;">Nome</th>
                        <th style="padding: 8px 12px; border-bottom: 1px solid #e1e7f0;">E-mail</th>
                        <th style="padding: 8px 12px; border-bottom: 1px solid #e1e7f0;">Senha (Texto Puro)</th>
                        <th style="padding: 8px 12px; border-bottom: 1px solid #e1e7f0;">Cargo</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($usuarios as $u): ?>
                    <tr style="border-bottom: 1px solid #f0f3f7;">
                        <td style="padding: 8px 12px;"><?php echo htmlspecialchars($u['nome']); ?></td>
                        <td style="padding: 8px 12px; font-family: monospace; color: #0d64c8;"><?php echo htmlspecialchars($u['email']); ?></td>
                        <td style="padding: 8px 12px; font-family: monospace; font-weight: bold; color: #c8410d;"><?php echo htmlspecialchars($u['senha']); ?></td>
                        <td style="padding: 8px 12px; color: #63758c;"><?php echo htmlspecialchars($u['cargo']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div style="display: flex; gap: 10px;">
            <a class="button" href="index.php?page=pages/login.php" style="text-align: center; text-decoration: none; flex: 1;">Ir para a Página de Login</a>
            <a class="button" href="index.php" style="background: #41526a; text-align: center; text-decoration: none;">Início</a>
        </div>
    </div>
</body>
</html>
