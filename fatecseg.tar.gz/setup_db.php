<?php
// FatecSeg Corp - Script de Inicialização do Banco de Dados
// Totalmente compatível com PHP 5.4.x / MariaDB / MySQL

error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);
ini_set('display_errors', '1');

require_once __DIR__ . '/config/db.php';

$usuarios = array(
    array('nome' => 'Administrador do Sistema', 'email' => 'admin@fatecseg.local', 'senha' => 'admin123', 'cargo' => 'Administrador Geral'),
    array('nome' => 'Carlos Eduardo Silva', 'email' => 'carlos.silva@fatecseg.local', 'senha' => 'carlos@2026', 'cargo' => 'Diretor de Operações (COO)'),
    array('nome' => 'Mariana Santos', 'email' => 'mariana.santos@fatecseg.local', 'senha' => 'mariana#segura', 'cargo' => 'Gerente de Segurança da Informação (CISO)'),
    array('nome' => 'Roberto Almeida', 'email' => 'roberto.almeida@fatecseg.local', 'senha' => 'roberto@pass', 'cargo' => 'Analista SOC Sênior'),
    array('nome' => 'Fernanda Costa', 'email' => 'fernanda.costa@fatecseg.local', 'senha' => 'fernanda1234', 'cargo' => 'Especialista em Resposta a Incidentes'),
    array('nome' => 'Lucas Oliveira', 'email' => 'lucas.oliveira@fatecseg.local', 'senha' => 'lucas#fatec', 'cargo' => 'Engenheiro de DevSecOps'),
    array('nome' => 'Patrícia Souza', 'email' => 'patricia.souza@fatecseg.local', 'senha' => 'patricia987', 'cargo' => 'Auditora de Conformidade e LGPD'),
    array('nome' => 'Bruno Lima', 'email' => 'bruno.lima@fatecseg.local', 'senha' => 'bruno@corp26', 'cargo' => 'Analista de Inteligência de Ameaças'),
    array('nome' => 'Juliana Mendes', 'email' => 'juliana.mendes@fatecseg.local', 'senha' => 'juliana@mendes', 'cargo' => 'Coordenadora de Recursos Humanos'),
    array('nome' => 'Tiago Ferreira', 'email' => 'tiago.ferreira@fatecseg.local', 'senha' => 'tiago@seg2026', 'cargo' => 'Arquiteto de Soluções em Nuvem'),
    array('nome' => 'Eduardo Ramos', 'email' => 'eduardo.ramos@fatecseg.local', 'senha' => 'suporte#2026', 'cargo' => 'Analista de Suporte Técnico'),
    array('nome' => 'Beatriz Rocha', 'email' => 'beatriz.rocha@fatecseg.local', 'senha' => 'financas@fatec', 'cargo' => 'Supervisora Financeira')
);

$messages = array();
$status = 'info';

// 1. Tenta criar o banco de dados no MySQL se não existir
if (extension_loaded('mysqli')) {
    $rootConn = @mysqli_connect(DB_HOST, DB_USER, DB_PASS, '', (int)DB_PORT);
    if ($rootConn) {
        $createDbSql = "CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
        @mysqli_query($rootConn, $createDbSql);
        @mysqli_close($rootConn);
    }
} elseif (extension_loaded('mysql')) {
    $rootLink = @mysql_connect(DB_HOST . ':' . DB_PORT, DB_USER, DB_PASS);
    if ($rootLink) {
        @mysql_query("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "`", $rootLink);
        @mysql_close($rootLink);
    }
}

// 2. Conecta ao banco
$conn = getDbConnection();

if (!$conn) {
    $messages[] = "[ERRO] Não foi possível conectar ao MySQL/MariaDB. Verifique se o serviço mysql está ativo (sudo service mysql start).";
    $status = 'error';
} else {
    // 3. Cria tabela e popula
    if (is_object($conn) && $conn instanceof mysqli) {
        @mysqli_query($conn, "DROP TABLE IF EXISTS `usuarios`");
        $tableSql = "CREATE TABLE `usuarios` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `nome` VARCHAR(120) NOT NULL,
            `email` VARCHAR(150) NOT NULL UNIQUE,
            `senha` VARCHAR(255) NOT NULL,
            `cargo` VARCHAR(100) NOT NULL,
            `criado_em` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        
        if (@mysqli_query($conn, $tableSql)) {
            $messages[] = "[MySQL] Tabela 'usuarios' criada com sucesso.";
            $inserted = 0;
            foreach ($usuarios as $u) {
                $n = mysqli_real_escape_string($conn, $u['nome']);
                $e = mysqli_real_escape_string($conn, $u['email']);
                $s = mysqli_real_escape_string($conn, $u['senha']);
                $c = mysqli_real_escape_string($conn, $u['cargo']);
                if (@mysqli_query($conn, "INSERT INTO `usuarios` (`nome`, `email`, `senha`, `cargo`) VALUES ('$n', '$e', '$s', '$c')")) {
                    $inserted++;
                }
            }
            $messages[] = "[MySQL] $inserted usuários inseridos com senhas em texto puro.";
            $status = 'success';
        } else {
            $messages[] = "[MySQL ERRO] " . mysqli_error($conn);
            $status = 'error';
        }
    } elseif (is_resource($conn)) {
        // ext/mysql legada
        @mysql_query("DROP TABLE IF EXISTS `usuarios`", $conn);
        $tableSql = "CREATE TABLE `usuarios` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `nome` VARCHAR(120) NOT NULL,
            `email` VARCHAR(150) NOT NULL UNIQUE,
            `senha` VARCHAR(255) NOT NULL,
            `cargo` VARCHAR(100) NOT NULL,
            `criado_em` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8";
        
        if (@mysql_query($tableSql, $conn)) {
            $messages[] = "[MySQL] Tabela 'usuarios' criada com sucesso via driver legado.";
            $inserted = 0;
            foreach ($usuarios as $u) {
                $n = mysql_real_escape_string($u['nome'], $conn);
                $e = mysql_real_escape_string($u['email'], $conn);
                $s = mysql_real_escape_string($u['senha'], $conn);
                $c = mysql_real_escape_string($u['cargo'], $conn);
                if (@mysql_query("INSERT INTO `usuarios` (`nome`, `email`, `senha`, `cargo`) VALUES ('$n', '$e', '$s', '$c')", $conn)) {
                    $inserted++;
                }
            }
            $messages[] = "[MySQL] $inserted usuários inseridos com sucesso.";
            $status = 'success';
        }
    } elseif (is_object($conn) && $conn instanceof PDO) {
        $conn->exec("DROP TABLE IF EXISTS usuarios");
        $conn->exec("CREATE TABLE usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            senha TEXT NOT NULL,
            cargo TEXT NOT NULL,
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
        )");
        $inserted = 0;
        foreach ($usuarios as $u) {
            $stmt = $conn->prepare("INSERT INTO usuarios (nome, email, senha, cargo) VALUES (:nome, :email, :senha, :cargo)");
            if ($stmt->execute(array(
                ':nome' => $u['nome'],
                ':email' => $u['email'],
                ':senha' => $u['senha'],
                ':cargo' => $u['cargo']
            ))) {
                $inserted++;
            }
        }
        $messages[] = "[SQLite Fallback] $inserted usuários inseridos com sucesso.";
        $status = 'success';
    }
}

// Se for CLI
if (php_sapi_name() === 'cli') {
    echo "====================================================\n";
    echo " FatecSeg Corp - Inicialização do Banco\n";
    echo "====================================================\n";
    foreach ($messages as $m) echo $m . "\n";
    exit(0);
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <title>Setup do Banco | FatecSeg Corp</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body style="background: #f0f4f9; display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 20px;">
    <div style="background: #fff; max-width: 650px; width: 100%; border-radius: 8px; box-shadow: 0 10px 25px rgba(0,0,0,0.08); padding: 35px; border: 1px solid #e1e7f0;">
        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 20px;">
            <span class="brand-mark" style="width: 36px; height: 36px; font-size: 14px;">FS</span>
            <div>
                <strong style="font-size: 18px; color: #0d2038;">FatecSeg Corp</strong>
                <div style="font-size: 12px; color: #63758c;">Inicialização do Banco de Dados</div>
            </div>
        </div>

        <h2 style="color: #11263f; margin-bottom: 15px;">Status da Instalação</h2>

        <div style="background: #172133; color: #9df0b8; padding: 18px; border-radius: 6px; font-family: monospace; font-size: 13px; line-height: 1.6; margin-bottom: 25px;">
            <?php foreach ($messages as $msg): ?>
                <div>&gt; <?php echo htmlspecialchars($msg); ?></div>
            <?php endforeach; ?>
        </div>

        <div style="display: flex; gap: 10px;">
            <a class="button" href="index.php?page=pages/login.php" style="text-align: center; text-decoration: none; flex: 1;">Ir para a Página de Login</a>
            <a class="button" href="index.php" style="background: #41526a; text-align: center; text-decoration: none;">Início</a>
        </div>
    </div>
</body>
</html>
