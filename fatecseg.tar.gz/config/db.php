﻿<?php
// FatecSeg Corp - Configuração de Conexão com o Banco de Dados
// Suporta MySQL / MariaDB (padrão) e SQLite como fallback.

if (!defined('DB_HOST')) define('DB_HOST', 'localhost');
if (!defined('DB_USER')) define('DB_USER', 'root');
if (!defined('DB_PASS')) define('DB_PASS', '');
if (!defined('DB_NAME')) define('DB_NAME', 'fatecseg_corp');
if (!defined('DB_PORT')) define('DB_PORT', 3306);

/**
 * Retorna uma conexão mysqli com o banco de dados MySQL/MariaDB
 * ou instancia PDO SQLite caso MySQL não esteja disponível.
 */
function getDbConnection()
{
    static $conn = null;
    if ($conn !== null) {
        return $conn;
    }

    // 1. Tenta conexão com MySQL (mysqli)
    if (extension_loaded('mysqli')) {
        mysqli_report(MYSQLI_REPORT_OFF);
        $conn = @mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);
        if ($conn) {
            mysqli_set_charset($conn, 'utf8');
            return $conn;
        }
    }

    // 2. Fallback para SQLite caso MySQL não esteja ativo (facilita testes didáticos locais)
    $dataDir = __DIR__ . '/../data';
    if (!is_dir($dataDir)) {
        @mkdir($dataDir, 0777, true);
    }
    $sqlitePath = $dataDir . '/fatecseg.sqlite';

    if (extension_loaded('pdo_sqlite')) {
        try {
            $pdo = new PDO('sqlite:' . $sqlitePath);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_SILENT);
            // Garante criação da tabela se sqlite for novo
            $pdo->exec("CREATE TABLE IF NOT EXISTS usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                senha TEXT NOT NULL,
                cargo TEXT NOT NULL,
                criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
            )");
            return $pdo;
        } catch (Exception $e) {
            // Falha ao abrir SQLite
        }
    }

    return null;
}

/**
 * Executa uma query SQL direta (propositadamente vulnerável a SQLi para o laboratório)
 * Retorna array com ['success' => bool, 'data' => array|null, 'error' => string|null, 'query' => string]
 */
function db_query_vulnerable($sql)
{
    $conn = getDbConnection();
    if (!$conn) {
        return array(
            'success' => false,
            'data' => null,
            'error' => 'Não foi possível conectar ao banco de dados MySQL ou SQLite. Verifique as configurações em config/db.php ou execute o script setup_db.php.',
            'query' => $sql
        );
    }

    // Se for mysqli
    if ($conn instanceof mysqli || is_resource($conn)) {
        $result = @mysqli_query($conn, $sql);
        if (!$result) {
            return array(
                'success' => false,
                'data' => null,
                'error' => mysqli_error($conn),
                'query' => $sql
            );
        }

        if ($result === true) {
            return array(
                'success' => true,
                'data' => null,
                'error' => null,
                'query' => $sql
            );
        }

        $rows = array();
        while ($row = mysqli_fetch_assoc($result)) {
            $rows[] = $row;
        }
        mysqli_free_result($result);

        return array(
            'success' => true,
            'data' => $rows,
            'error' => null,
            'query' => $sql
        );
    }

    // Se for PDO (SQLite)
    if ($conn instanceof PDO) {
        $stmt = $conn->query($sql);
        if (!$stmt) {
            $err = $conn->errorInfo();
            return array(
                'success' => false,
                'data' => null,
                'error' => isset($err[2]) ? $err[2] : 'Erro na consulta SQL',
                'query' => $sql
            );
        }

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return array(
            'success' => true,
            'data' => $rows,
            'error' => null,
            'query' => $sql
        );
    }

    return array(
        'success' => false,
        'data' => null,
        'error' => 'Tipo de conexão não reconhecido.',
        'query' => $sql
    );
}
