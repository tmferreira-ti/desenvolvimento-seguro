<?php
// FatecSeg Corp - Configuração de Conexão com o Banco de Dados
// Totalmente compatível com PHP 5.4.x (Ubuntu 14.04 / Apache 2.4 / MariaDB / MySQL)

if (!defined('DB_HOST')) define('DB_HOST', 'localhost');
if (!defined('DB_USER')) define('DB_USER', 'root');
if (!defined('DB_PASS')) define('DB_PASS', '');
if (!defined('DB_NAME')) define('DB_NAME', 'fatecseg_corp');
if (!defined('DB_PORT')) define('DB_PORT', 3306);

/**
 * Retorna conexão com o banco de dados (mysqli, mysql legada ou SQLite PDO)
 */
function getDbConnection()
{
    static $conn = null;
    if ($conn !== null) {
        return $conn;
    }

    // 1. Tenta mysqli
    if (extension_loaded('mysqli')) {
        if (function_exists('mysqli_report') && defined('MYSQLI_REPORT_OFF')) {
            @mysqli_report(MYSQLI_REPORT_OFF);
        }
        $conn = @mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME, (int)DB_PORT);
        if ($conn) {
            @mysqli_set_charset($conn, 'utf8');
            return $conn;
        }
    }

    // 2. Tenta ext/mysql legada (PHP 5.4)
    if (extension_loaded('mysql')) {
        $link = @mysql_connect(DB_HOST . ':' . DB_PORT, DB_USER, DB_PASS);
        if ($link && @mysql_select_db(DB_NAME, $link)) {
            @mysql_set_charset('utf8', $link);
            $conn = $link;
            return $conn;
        }
    }

    // 3. Fallback transparente SQLite PDO
    $dataDir = __DIR__ . '/../data';
    if (!is_dir($dataDir)) {
        @mkdir($dataDir, 0777, true);
    }
    $sqlitePath = $dataDir . '/fatecseg.sqlite';

    if (class_exists('PDO') && extension_loaded('pdo_sqlite')) {
        try {
            $pdo = new PDO('sqlite:' . $sqlitePath);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_SILENT);
            $pdo->exec("CREATE TABLE IF NOT EXISTS usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                senha TEXT NOT NULL,
                cargo TEXT NOT NULL,
                criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
            )");
            return $pdo;
        } catch (Exception $e) {
            // Falha silenciosa no sqlite
        }
    }

    return null;
}

/**
 * Executa query propositadamente vulnerável a SQL Injection
 */
function db_query_vulnerable($sql)
{
    $conn = getDbConnection();
    if (!$conn) {
        return array(
            'success' => false,
            'data' => null,
            'error' => 'Não foi possível conectar ao MySQL. Certifique-se de que o MariaDB/MySQL está rodando e execute o setup_db.php.',
            'query' => $sql
        );
    }

    // Caso mysqli
    if (is_object($conn) && $conn instanceof mysqli) {
        $result = @mysqli_query($conn, $sql);
        if ($result === false) {
            return array(
                'success' => false,
                'data' => null,
                'error' => mysqli_error($conn),
                'query' => $sql
            );
        }

        if ($result === true) {
            return array(
                'success' => true,
                'data' => null,
                'error' => null,
                'query' => $sql
            );
        }

        $rows = array();
        while ($row = mysqli_fetch_assoc($result)) {
            $rows[] = $row;
        }
        mysqli_free_result($result);

        return array(
            'success' => true,
            'data' => $rows,
            'error' => null,
            'query' => $sql
        );
    }

    // Caso ext/mysql legada
    if (is_resource($conn)) {
        $result = @mysql_query($sql, $conn);
        if ($result === false) {
            return array(
                'success' => false,
                'data' => null,
                'error' => mysql_error($conn),
                'query' => $sql
            );
        }

        if ($result === true) {
            return array(
                'success' => true,
                'data' => null,
                'error' => null,
                'query' => $sql
            );
        }

        $rows = array();
        while ($row = mysql_fetch_assoc($result)) {
            $rows[] = $row;
        }
        mysql_free_result($result);

        return array(
            'success' => true,
            'data' => $rows,
            'error' => null,
            'query' => $sql
        );
    }

    // Caso PDO SQLite
    if (is_object($conn) && $conn instanceof PDO) {
        $stmt = $conn->query($sql);
        if (!$stmt) {
            $err = $conn->errorInfo();
            return array(
                'success' => false,
                'data' => null,
                'error' => isset($err[2]) ? $err[2] : 'Erro na consulta SQL',
                'query' => $sql
            );
        }

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return array(
            'success' => true,
            'data' => $rows,
            'error' => null,
            'query' => $sql
        );
    }

    return array(
        'success' => false,
        'data' => null,
        'error' => 'Tipo de conexão inválido.',
        'query' => $sql
    );
}
