﻿<?php
// FatecSeg Corp - Portal Corporativo
// Compatível com PHP 5.x (Ubuntu Server 14.04 / Apache 2.4).

if (session_id() == '' || !isset($_SESSION)) {
    session_start();
}

$page = isset($_GET['page']) ? $_GET['page'] : 'pages/home.php';
$allowedMenuPages = array(
    'pages/home.php',
    'pages/company.php',
    'pages/services.php',
    'pages/news.php',
    'pages/contact.php',
    'pages/login.php',
    'pages/register.php',
    'pages/dashboard.php'
);

$isLoggedIn = isset($_SESSION['usuario_logado']) && $_SESSION['usuario_logado'] === true;

function activeMenu($target, $current)
{
    return $target === $current ? ' class="active"' : '';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Portal corporativo FatecSeg Corp">
    <title>FatecSeg Corp | Tecnologia que protege o futuro</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header class="topbar">
        <div class="container topbar-content">
            <span>Atendimento corporativo: (11) 4002-8922</span>
            <span>contato@fatecseg.local</span>
        </div>
    </header>

    <nav class="navbar">
        <div class="container nav-content">
            <a class="brand" href="index.php">
                <span class="brand-mark">FS</span>
                <span><strong>FatecSeg</strong><small>CORP</small></span>
            </a>
            <button class="menu-toggle" type="button" aria-label="Abrir menu">☰</button>
            <ul class="menu">
                <li><a<?php echo activeMenu('pages/home.php', $page); ?> href="index.php?page=pages/home.php">Início</a></li>
                <li><a<?php echo activeMenu('pages/company.php', $page); ?> href="index.php?page=pages/company.php">A empresa</a></li>
                <li><a<?php echo activeMenu('pages/services.php', $page); ?> href="index.php?page=pages/services.php">Soluções</a></li>
                <li><a<?php echo activeMenu('pages/news.php', $page); ?> href="index.php?page=pages/news.php">Notícias</a></li>
                <li><a<?php echo activeMenu('pages/contact.php', $page); ?> href="index.php?page=pages/contact.php">Contato</a></li>
                
                <?php if ($isLoggedIn): ?>
                    <li><a<?php echo activeMenu('pages/dashboard.php', $page); ?> href="index.php?page=pages/dashboard.php">Painel Restrito</a></li>
                    <li><a class="nav-logout-btn" href="index.php?page=pages/login.php&action=logout" title="Encerrar Sessão">Sair (<?php echo htmlspecialchars($_SESSION['usuario_nome']); ?>)</a></li>
                <?php else: ?>
                    <li><a class="nav-login-btn<?php echo in_array($page, array('pages/login.php', 'pages/register.php')) ? ' active' : ''; ?>" href="index.php?page=pages/login.php">Login</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <main>
        <?php
        // O portal carrega o conteúdo solicitado pela URL para manter a navegação modular.
        include($page);
        ?>
    </main>

    <footer>
        <div class="container footer-grid">
            <div>
                <div class="footer-brand">FatecSeg Corp</div>
                <p>Tecnologia, governança e confiança para operações críticas.</p>
            </div>
            <div>
                <strong>Escritório central</strong>
                <p>Av. Tecnologia, 404<br>São Paulo - SP</p>
            </div>
            <div>
                <strong>Central de relacionamento</strong>
                <p>Segunda a sexta, 8h às 18h<br>(11) 4002-8922</p>
            </div>
        </div>
        <div class="copyright">&copy; <?php echo date('Y'); ?> FatecSeg Corp. Todos os direitos reservados.</div>
    </footer>
    <script src="assets/js/app.js"></script>
</body>
</html>
