<section class="page-hero">
    <div class="container">
        <span class="eyebrow">SOLUÇÕES</span>
        <h1>Proteção alinhada à sua estratégia.</h1>
        <p>Um portfólio completo para ambientes digitais complexos.</p>
    </div>
</section>
<section class="section">
    <div class="container cards two">
        <article class="service-card"><span>01</span><div><h3>Security Operations Center</h3><p>Monitoramento, triagem, investigação e resposta a eventos com cobertura contínua.</p></div></article>
        <article class="service-card"><span>02</span><div><h3>Consultoria e governança</h3><p>Avaliação de maturidade, gestão de riscos, políticas e programas de conformidade.</p></div></article>
        <article class="service-card"><span>03</span><div><h3>Application Security</h3><p>Revisões de arquitetura, testes de segurança e integração de controles ao ciclo de desenvolvimento.</p></div></article>
        <article class="service-card"><span>04</span><div><h3>Resposta a incidentes</h3><p>Preparação, contenção, análise técnica e apoio à recuperação de ambientes.</p></div></article>
        <article class="service-card"><span>05</span><div><h3>Cloud Security</h3><p>Arquiteturas seguras, revisão de configurações e gestão de postura em nuvem.</p></div></article>
        <article class="service-card"><span>06</span><div><h3>Conscientização</h3><p>Programas práticos para desenvolver uma cultura de segurança em todos os níveis.</p></div></article>
    </div>
</section>
