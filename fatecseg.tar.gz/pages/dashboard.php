﻿<?php
// FatecSeg Corp - Painel Administrativo / Área Restrita
// Exibido após autenticação bem-sucedida (legítima ou via SQL Injection)

require_once __DIR__ . '/../config/db.php';

if (session_id() == '' || !isset($_SESSION)) {
    session_start();
}

if (!isset($_SESSION['usuario_logado']) || $_SESSION['usuario_logado'] !== true) {
    header("Location: index.php?page=pages/login.php");
    exit;
}

$nome = isset($_SESSION['usuario_nome']) ? $_SESSION['usuario_nome'] : 'Colaborador';
$email = isset($_SESSION['usuario_email']) ? $_SESSION['usuario_email'] : 'colaborador@fatecseg.local';
$cargo = isset($_SESSION['usuario_cargo']) ? $_SESSION['usuario_cargo'] : 'Membro Corporativo';
$lastQuery = isset($_SESSION['last_query']) ? $_SESSION['last_query'] : '';

// Consulta para listar usuários do banco (demonstração didática)
$usuariosResult = db_query_vulnerable("SELECT id, nome, email, senha, cargo, criado_em FROM usuarios ORDER BY id ASC");
$usuariosLista = ($usuariosResult['success'] && !empty($usuariosResult['data'])) ? $usuariosResult['data'] : array();
?>

<section class="page-hero compact" style="background: linear-gradient(110deg, #071a30, #0c4d8b);">
    <div class="container" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px;">
        <div>
            <span class="eyebrow" style="color: #61dfa8;">● SESSÃO AUTENTICADA COM SUCESSO</span>
            <h1 style="margin-bottom: 5px;"><?php echo htmlspecialchars($nome); ?></h1>
            <p><?php echo htmlspecialchars($cargo); ?> &bull; <code><?php echo htmlspecialchars($email); ?></code></p>
        </div>
        <div style="display: flex; gap: 10px;">
            <a class="button" href="index.php?page=pages/register.php" style="background: #0d64c8;">+ Testar INSERT SQLi</a>
            <a class="button" href="index.php?page=pages/login.php&action=logout" style="background: #d94242;">Encerrar Sessão</a>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        
        <?php if (!empty($lastQuery)): ?>
            <div style="background: #111d2e; border: 1px solid #233a59; border-radius: 6px; padding: 20px; margin-bottom: 35px; color: #d0e1f9;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                    <strong style="color: #61dfa8; font-size: 13px;">🔍 Query SQL Executada na Autenticação (Análise de Laboratório):</strong>
                    <span style="font-size: 11px; background: #1c324e; padding: 2px 8px; border-radius: 4px; color: #8cb6ea;">Painel Didático</span>
                </div>
                <pre style="margin: 0; font-family: monospace; font-size: 13px; color: #ffca65; background: #08101a; padding: 12px; border-radius: 4px; overflow-x: auto; white-space: pre-wrap;"><?php echo htmlspecialchars($lastQuery); ?></pre>
                <div style="font-size: 12px; color: #9bbad9; margin-top: 8px;">
                    Se esta autenticação ocorreu via SQLi (ex: <code>' OR '1'='1</code> ou <code>' -- </code>), a consulta acima validou como verdadeira ignorando a checagem segura da senha.
                </div>
            </div>
        <?php endif; ?>

        <div class="section-heading" style="text-align: left; margin-bottom: 30px;">
            <span class="eyebrow dark">BANCO DE DADOS CORPORATIVO</span>
            <h2>Contas Cadastradas no Sistema</h2>
            <p>Lista de usuários registrados e suas senhas (armazenadas em texto puro conforme instrução da aula de segurança):</p>
        </div>

        <div style="background: #fff; border: 1px solid #e2e8ef; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,.04); margin-bottom: 40px;">
            <div style="overflow-x: auto;">
                <table style="width: 100%; border-collapse: collapse; text-align: left; font-size: 13px;">
                    <thead style="background: #f4f7fb; color: #334e68; border-bottom: 2px solid #e1e8f0;">
                        <tr>
                            <th style="padding: 12px 16px;"># ID</th>
                            <th style="padding: 12px 16px;">Nome Completo</th>
                            <th style="padding: 12px 16px;">E-mail Corporativo</th>
                            <th style="padding: 12px 16px; color: #c8410d;">Senha (Texto Puro)</th>
                            <th style="padding: 12px 16px;">Cargo / Atribuição</th>
                            <th style="padding: 12px 16px;">Criado Em</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($usuariosLista)): ?>
                            <tr>
                                <td colspan="6" style="padding: 20px; text-align: center; color: #8292a2;">
                                    Nenhum usuário encontrado no banco de dados. Execute o <a href="setup_db.php" style="color:#0d64c8; font-weight:bold;">setup_db.php</a> para popular as contas.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($usuariosLista as $usr): ?>
                                <tr style="border-bottom: 1px solid #edf2f7; transition: background 0.15s;" onmouseover="this.style.background='#f8fbff'" onmouseout="this.style.background='transparent'">
                                    <td style="padding: 12px 16px; font-weight: bold; color: #64748b;"><?php echo htmlspecialchars($usr['id']); ?></td>
                                    <td style="padding: 12px 16px; font-weight: 600; color: #1e293b;"><?php echo htmlspecialchars($usr['nome']); ?></td>
                                    <td style="padding: 12px 16px; font-family: monospace; color: #0d64c8;"><?php echo htmlspecialchars($usr['email']); ?></td>
                                    <td style="padding: 12px 16px; font-family: monospace; font-weight: bold; color: #d94242; background: #fff5f5;"><?php echo htmlspecialchars($usr['senha']); ?></td>
                                    <td style="padding: 12px 16px; color: #475569;"><?php echo htmlspecialchars($usr['cargo']); ?></td>
                                    <td style="padding: 12px 16px; color: #94a3b8; font-size: 12px;"><?php echo htmlspecialchars(isset($usr['criado_em']) ? $usr['criado_em'] : '-'); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="cards three">
            <div class="card">
                <span class="icon">🔒</span>
                <h3>Controle de Acesso</h3>
                <p>Políticas de privilégios mínimos e segregação de funções em ambientes produtivos.</p>
            </div>
            <div class="card">
                <span class="icon">🛡️</span>
                <h3>Remediação de SQLi</h3>
                <p>Utilização de PDO Prepared Statements ou parametrização com mysqli_stmt_bind_param.</p>
            </div>
            <div class="card">
                <span class="icon">🔑</span>
                <h3>Armazenamento de Senhas</h3>
                <p>Uso obrigatório de algoritmos de hash seguros como Argon2id ou Bcrypt com salt.</p>
            </div>
        </div>

    </div>
</section>
