<?php
// FatecSeg Corp - Cadastro de Usuários / Solicitação de Acesso
// AVISO DIDÁTICO: Este script demonstra propositalmente vulnerabilidade a SQL Injection em comandos INSERT INTO
// para a disciplina de Desenvolvimento Seguro.

require_once __DIR__ . '/../config/db.php';

if (session_id() == '' || !isset($_SESSION)) {
    session_start();
}

$successMsg = '';
$errorMsg = '';
$executedQuery = '';
$debugSqlError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = isset($_POST['nome']) ? $_POST['nome'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $senha = isset($_POST['senha']) ? $_POST['senha'] : '';
    
    // Regra de Negócio: O sistema define fixamente que novos cadastros públicos
    // recebem apenas o cargo básico "Visitante / Colaborador Nível 1"
    $cargoPadrao = 'Visitante / Colaborador Nível 1';

    if (empty($nome) || empty($email) || empty($senha)) {
        $errorMsg = 'Por favor, preencha todos os campos obrigatórios.';
    } else {
        // ====================================================================
        // VULNERABILIDADE INTENCIONAL: SQL Injection em comando INSERT
        // Concatenação direta sem prepared statements ou sanitização.
        // ====================================================================
        $sql = "INSERT INTO usuarios (nome, email, senha, cargo) VALUES ('$nome', '$email', '$senha', '$cargoPadrao')";
        $executedQuery = $sql;

        $res = db_query_vulnerable($sql);

        if (!$res['success']) {
            $errorMsg = 'Falha ao registrar novo usuário.';
            $debugSqlError = $res['error'];
        } else {
            $successMsg = 'Cadastro realizado com sucesso!';
        }
    }
}

// Busca os últimos 5 cadastros para demonstrar o resultado da inserção
$ultimosRes = db_query_vulnerable("SELECT id, nome, email, senha, cargo, criado_em FROM usuarios ORDER BY id DESC LIMIT 5");
$ultimosUsuarios = ($ultimosRes['success'] && !empty($ultimosRes['data'])) ? $ultimosRes['data'] : array();
?>

<section class="page-hero compact">
    <div class="container">
        <span class="eyebrow">NOVO ACESSO</span>
        <h1>Cadastro de Colaborador</h1>
        <p>Demonstração de vulnerabilidade de injeção em instruções <code>INSERT INTO</code>.</p>
    </div>
</section>

<section class="section">
    <div class="container" style="max-width: 700px; margin: 0 auto;">

        <?php if (!empty($successMsg)): ?>
            <div class="success-message" style="margin-bottom: 20px;">
                <strong><?php echo htmlspecialchars($successMsg); ?></strong>
                <p style="margin-top: 5px; margin-bottom: 0;">Você já pode realizar login com as novas credenciais inseridas.</p>
                <div style="margin-top: 10px;">
                    <a href="index.php?page=pages/login.php" class="button" style="padding: 8px 16px; font-size: 13px;">Ir para o Login</a>
                </div>
            </div>
        <?php endif; ?>

        <?php if (!empty($errorMsg)): ?>
            <div style="padding: 16px; margin-bottom: 20px; color: #a92020; background: #ffebeb; border: 1px solid #f5c2c2; border-radius: 5px;">
                <strong>Atenção:</strong> <?php echo htmlspecialchars($errorMsg); ?>
                <?php if (!empty($debugSqlError)): ?>
                    <div style="margin-top: 10px; font-family: monospace; font-size: 12px; background: #fff; padding: 10px; border: 1px solid #f0b0b0; border-radius: 3px; color: #781010; word-break: break-all;">
                        <strong>SQL Error:</strong> <?php echo htmlspecialchars($debugSqlError); ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($executedQuery)): ?>
            <div style="background: #111d2e; border: 1px solid #233a59; border-radius: 6px; padding: 16px; margin-bottom: 25px; color: #d0e1f9;">
                <div style="font-size: 11px; color: #61dfa8; font-weight: bold; margin-bottom: 6px;">
                    🔍 Query INSERT Executada no Banco:
                </div>
                <pre style="margin: 0; font-family: monospace; font-size: 12px; color: #ffca65; background: #08101a; padding: 10px; border-radius: 4px; overflow-x: auto; white-space: pre-wrap;"><?php echo htmlspecialchars($executedQuery); ?></pre>
            </div>
        <?php endif; ?>

        <div class="login-card" style="background: #fff; padding: 35px; border-radius: 8px; border: 1px solid #e2e8ef; box-shadow: 0 4px 15px rgba(13,32,56,.06); margin-bottom: 30px;">
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid #edf2f7;">
                <span class="brand-mark" style="width: 38px; height: 38px;">FS</span>
                <div>
                    <h2 style="margin: 0; font-size: 20px; color: #0d2038;">Formulário de Cadastro</h2>
                    <small style="color: #63758c;">Preencha os dados corporativos abaixo</small>
                </div>
            </div>

            <form method="post" action="index.php?page=pages/register.php">
                <div style="margin-bottom: 16px;">
                    <label for="nome" style="display: block; margin-bottom: 6px; font-weight: bold; color: #263b54; font-size: 13px;">
                        Nome Completo
                    </label>
                    <input type="text" id="nome" name="nome" value="<?php echo isset($_POST['nome']) ? htmlspecialchars($_POST['nome']) : ''; ?>" placeholder="ex: João Silva" style="width: 100%; box-sizing: border-box; padding: 11px; border: 1px solid #ccd6e0; border-radius: 4px; font: inherit;" required>
                </div>

                <div style="margin-bottom: 16px;">
                    <label for="email" style="display: block; margin-bottom: 6px; font-weight: bold; color: #263b54; font-size: 13px;">
                        E-mail Corporativo
                    </label>
                    <input type="text" id="email" name="email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" placeholder="ex: joao.silva@fatecseg.local" style="width: 100%; box-sizing: border-box; padding: 11px; border: 1px solid #ccd6e0; border-radius: 4px; font: inherit;" required>
                </div>

                <div style="margin-bottom: 16px;">
                    <label for="senha" style="display: block; margin-bottom: 6px; font-weight: bold; color: #263b54; font-size: 13px;">
                        Senha
                    </label>
                    <input type="password" id="senha" name="senha" placeholder="Digite uma senha" style="width: 100%; box-sizing: border-box; padding: 11px; border: 1px solid #ccd6e0; border-radius: 4px; font: inherit;" required>
                </div>

                <div style="margin-bottom: 22px; padding: 12px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 4px; font-size: 12px; color: #64748b;">
                    <strong>Perfil atribuído automaticamente:</strong> Visitante / Colaborador Nível 1 <em>(Não editável pelo usuário)</em>
                </div>

                <div style="display: flex; gap: 10px;">
                    <button class="button" type="submit" style="flex: 1; padding: 13px; font-size: 14px; text-align: center;">
                        Cadastrar Usuário
                    </button>
                    <a href="index.php?page=pages/login.php" class="button" style="background: #475569; padding: 13px 20px; font-size: 14px; text-align: center;">
                        Voltar ao Login
                    </a>
                </div>
            </form>
        </div>

        <!-- Painel Didático de Demonstração de SQL Injection em INSERT -->
        <div style="margin-bottom: 30px; background: #edf4fc; border: 1px solid #c7ddf5; border-radius: 6px; padding: 20px; font-size: 13px; color: #1e3a5f;">
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px;">
                <strong style="color: #0d4a8f; font-size: 14px;"> Laboratório Didático — SQL Injection em INSERT INTO</strong>
                <span style="background: #0d64c8; color: #fff; font-size: 10px; padding: 2px 8px; border-radius: 12px; font-weight: bold;">INSERT LAB</span>
            </div>
            <p style="margin-bottom: 12px; line-height: 1.5;">
                Em comandos <code>INSERT INTO</code>, a injeção permite ao invasor <strong>fechar a lista de valores prematuramente</strong>, injetar valores customizados (como elevar o cargo para <code>Administrador Geral</code>) ou injetar subconsultas.
            </p>
            <div style="background: #fff; padding: 12px; border-radius: 4px; border: 1px solid #d4e3f5; margin-bottom: 12px; font-family: monospace; font-size: 11.5px; color: #334e68; overflow-x: auto;">
                INSERT INTO usuarios (nome, email, senha, cargo) VALUES ('<span style="color:#c8410d; font-weight:bold;">$nome</span>', '<span style="color:#c8410d; font-weight:bold;">$email</span>', '<span style="color:#c8410d; font-weight:bold;">$senha</span>', 'Visitante / Colaborador Nível 1')
            </div>
            <details style="cursor: pointer; margin-top: 8px;">
                <summary style="font-weight: bold; color: #0d64c8;">Ver exemplos de payloads para teste de INSERT SQLi</summary>
                <div style="margin-top: 10px; padding: 12px; background: #fff; border-radius: 4px; border: 1px solid #d4e3f5; font-size: 12px; line-height: 1.6;">
                    <strong>🎯 Desafio: Elevação de Privilégio (Injetar Cargo de Administrador):</strong>
                    <p style="margin: 5px 0 8px;">Como o sistema define o cargo como "Visitante", injete no campo <strong>Nome</strong> fechando os valores restantes e comentando o final:</p>
                    <ul style="margin: 0; padding-left: 18px;">
                        <li><strong>Campo Nome:</strong> <code>Hacker', 'hacker@fatecseg.local', 'senha123', 'Administrador Geral') -- </code></li>
                        <li><strong>Campo E-mail:</strong> <code>qualquer@email.com</code></li>
                        <li><strong>Campo Senha:</strong> <code>123</code></li>
                        <li><em>Resultado:</em> O usuário <code>hacker@fatecseg.local</code> será inserido com o cargo de <strong>Administrador Geral</strong>!</li>
                    </ul>
                </div>
            </details>
        </div>

        <!-- Tabela dos últimos usuários inseridos -->
        <div style="background: #fff; border: 1px solid #e2e8ef; border-radius: 8px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,.04);">
            <h3 style="font-size: 15px; margin-bottom: 12px; color: #1e293b;">Últimos Registros no Banco de Dados:</h3>
            <div style="overflow-x: auto;">
                <table style="width: 100%; border-collapse: collapse; font-size: 12px; text-align: left;">
                    <thead>
                        <tr style="background: #f8fafc; color: #475569; border-bottom: 1px solid #e2e8f0;">
                            <th style="padding: 8px 10px;"># ID</th>
                            <th style="padding: 8px 10px;">Nome</th>
                            <th style="padding: 8px 10px;">E-mail</th>
                            <th style="padding: 8px 10px;">Senha</th>
                            <th style="padding: 8px 10px;">Cargo Registrado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($ultimosUsuarios as $u): ?>
                        <tr style="border-bottom: 1px solid #f1f5f9;">
                            <td style="padding: 8px 10px; color: #64748b;"><?php echo htmlspecialchars($u['id']); ?></td>
                            <td style="padding: 8px 10px; font-weight: bold; color: #1e293b;"><?php echo htmlspecialchars($u['nome']); ?></td>
                            <td style="padding: 8px 10px; font-family: monospace; color: #0d64c8;"><?php echo htmlspecialchars($u['email']); ?></td>
                            <td style="padding: 8px 10px; font-family: monospace; color: #d94242;"><?php echo htmlspecialchars($u['senha']); ?></td>
                            <td style="padding: 8px 10px; font-weight: 600; color: <?php echo strpos($u['cargo'], 'Admin') !== false ? '#0d64c8' : '#64748b'; ?>;">
                                <?php echo htmlspecialchars($u['cargo']); ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</section>
