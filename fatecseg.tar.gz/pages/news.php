<section class="page-hero compact">
    <div class="container">
        <span class="eyebrow">INSIGHTS</span>
        <h1>Notícias e conhecimento</h1>
    </div>
</section>
<section class="section">
    <div class="container news-list">
        <article><time>18 SET 2026</time><div><span>TECNOLOGIA</span><h2>FatecSeg amplia capacidade do Centro de Operações</h2><p>A nova estrutura aumenta a capacidade de análise e acelera a resposta aos clientes.</p></div></article>
        <article><time>02 SET 2026</time><div><span>NEGÓCIOS</span><h2>Segurança como habilitadora da transformação digital</h2><p>Conheça os pilares que conectam proteção, agilidade e geração de valor.</p></div></article>
        <article><time>21 AGO 2026</time><div><span>PESSOAS</span><h2>Programa de formação abre vagas para novos talentos</h2><p>Iniciativa aproxima estudantes dos desafios reais da segurança da informação.</p></div></article>
    </div>
</section>
