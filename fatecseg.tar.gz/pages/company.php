<section class="page-hero">
    <div class="container">
        <span class="eyebrow">QUEM SOMOS</span>
        <h1>Confiança se constrói todos os dias.</h1>
        <p>Somos uma empresa brasileira de tecnologia dedicada a proteger operações essenciais.</p>
    </div>
</section>
<section class="section">
    <div class="container split">
        <div>
            <span class="eyebrow dark">FATECSEG CORP</span>
            <h2>Conhecimento técnico com visão de negócio</h2>
            <p>Fundada em 2014, a FatecSeg Corp nasceu da união de especialistas em infraestrutura, desenvolvimento e governança. Atuamos em todo o ciclo de segurança, da estratégia à operação.</p>
            <p>Nossa equipe combina experiência prática, pesquisa contínua e proximidade com o cliente para entregar resultados mensuráveis.</p>
        </div>
        <div class="quote-box">
            <p>“Segurança eficaz é aquela que sustenta a inovação sem perder de vista as pessoas e o negócio.”</p>
            <strong>Diretoria Executiva</strong>
        </div>
    </div>
    <div class="container values">
        <div><h3>Missão</h3><p>Fortalecer organizações por meio de soluções digitais confiáveis.</p></div>
        <div><h3>Visão</h3><p>Ser referência nacional em segurança aplicada aos negócios.</p></div>
        <div><h3>Valores</h3><p>Ética, excelência técnica, colaboração e aprendizado contínuo.</p></div>
    </div>
</section>
