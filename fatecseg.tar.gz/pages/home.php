<section class="hero">
    <div class="container hero-content">
        <div class="hero-copy">
            <span class="eyebrow">INOVAÇÃO COM CONFIANÇA</span>
            <h1>Segurança para negócios que não podem parar.</h1>
            <p>A FatecSeg Corp conecta tecnologia, processos e pessoas para transformar riscos em decisões inteligentes.</p>
            <a class="button" href="index.php?page=pages/services.php">Conheça nossas soluções</a>
        </div>
        <div class="hero-panel">
            <span class="status-dot"></span>
            <small>CENTRO DE OPERAÇÕES</small>
            <strong>Monitoramento contínuo</strong>
            <div class="metric"><span>Disponibilidade</span><b>99,98%</b></div>
            <div class="metric"><span>Ativos monitorados</span><b>2.840</b></div>
            <div class="metric"><span>Eventos analisados/dia</span><b>1,2M</b></div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section-heading">
            <span class="eyebrow dark">NOSSA ATUAÇÃO</span>
            <h2>Estratégia e proteção em cada camada</h2>
            <p>Serviços especializados para organizações que buscam crescer com previsibilidade e resiliência.</p>
        </div>
        <div class="cards three">
            <article class="card">
                <span class="icon">01</span>
                <h3>Operações de segurança</h3>
                <p>Visibilidade centralizada, correlação de eventos e resposta coordenada a incidentes.</p>
            </article>
            <article class="card">
                <span class="icon">02</span>
                <h3>Gestão de riscos</h3>
                <p>Mapeamento de ameaças, priorização de controles e apoio à tomada de decisão.</p>
            </article>
            <article class="card">
                <span class="icon">03</span>
                <h3>Transformação segura</h3>
                <p>Segurança integrada ao desenvolvimento e à modernização de ambientes digitais.</p>
            </article>
        </div>
    </div>
</section>

<section class="stats">
    <div class="container stats-grid">
        <div><strong>12+</strong><span>anos de experiência</span></div>
        <div><strong>180</strong><span>especialistas</span></div>
        <div><strong>96%</strong><span>retenção de clientes</span></div>
        <div><strong>24x7</strong><span>operações monitoradas</span></div>
    </div>
</section>
