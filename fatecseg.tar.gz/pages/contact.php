<?php
$sent = isset($_POST['name']) && trim($_POST['name']) !== '';
?>
<section class="page-hero compact">
    <div class="container">
        <span class="eyebrow">FALE CONOSCO</span>
        <h1>Vamos conversar?</h1>
        <p>Conte brevemente o seu desafio. Nossa equipe entrará em contato.</p>
    </div>
</section>
<section class="section">
    <div class="container contact-layout">
        <div>
            <h2>Inicie uma conversa</h2>
            <p>Preencha o formulário ou fale diretamente com nossa central de relacionamento.</p>
            <div class="contact-data"><strong>E-mail</strong><span>contato@fatecseg.local</span></div>
            <div class="contact-data"><strong>Telefone</strong><span>(11) 4002-8922</span></div>
            <div class="contact-data"><strong>Endereço</strong><span>Av. Tecnologia, 404 — São Paulo/SP</span></div>
        </div>
        <div>
            <?php if ($sent): ?>
                <div class="success-message"><strong>Mensagem recebida.</strong><br>Nossa equipe retornará o contato em breve.</div>
            <?php else: ?>
                <form class="contact-form" method="post" action="index.php?page=pages/contact.php">
                    <label>Nome<input type="text" name="name" required></label>
                    <label>E-mail corporativo<input type="email" name="email" required></label>
                    <label>Empresa<input type="text" name="company"></label>
                    <label>Mensagem<textarea name="message" rows="5" required></textarea></label>
                    <button class="button" type="submit">Enviar mensagem</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</section>
