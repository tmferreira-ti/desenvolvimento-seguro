﻿<?php
// FatecSeg Corp - Portal de Autenticação Corporativo
// AVISO DIDÁTICO: Este script contém intencionalmente vulnerabilidade a SQL Injection (SQLi)
// para uso exclusivo em aulas e laboratórios da disciplina de Desenvolvimento Seguro.

require_once __DIR__ . '/../config/db.php';

// Inicializa sessão se não estiver iniciada
if (session_id() == '' || !isset($_SESSION)) {
    session_start();
}

$error = '';
$executedQuery = '';
$debugSqlError = '';

// Processa Logout
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    $_SESSION = array();
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
    header("Location: index.php?page=pages/login.php&logged_out=1");
    exit;
}

// Se já estiver logado, redireciona para o dashboard
if (isset($_SESSION['usuario_logado']) && $_SESSION['usuario_logado'] === true && !isset($_GET['action'])) {
    header("Location: index.php?page=pages/dashboard.php");
    exit;
}

// Processa tentativa de Login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $senha = isset($_POST['senha']) ? $_POST['senha'] : '';

    if (empty($email) && empty($senha)) {
        $error = 'Por favor, informe as credenciais de acesso.';
    } else {
        // ====================================================================
        // VULNERABILIDADE INTENCIONAL: SQL Injection (SQLi)
        // Concatenação direta de parâmetros do usuário sem sanitização
        // e sem uso de Prepared Statements / Consultas Parametrizadas.
        // ====================================================================
        $sql = "SELECT * FROM usuarios WHERE email = '$email' AND senha = '$senha'";
        $executedQuery = $sql;

        $res = db_query_vulnerable($sql);

        if (!$res['success']) {
            // Em aulas de segurança, expor o erro de banco permite entender SQLi baseado em erro
            $error = 'Erro na execução da consulta SQL.';
            $debugSqlError = $res['error'];
        } elseif (!empty($res['data'])) {
            // Usuário autenticado com sucesso (ou bypass via SQLi)
            $usuario = $res['data'][0];
            $_SESSION['usuario_logado'] = true;
            $_SESSION['usuario_id'] = isset($usuario['id']) ? $usuario['id'] : 1;
            $_SESSION['usuario_nome'] = isset($usuario['nome']) ? $usuario['nome'] : 'Usuário Autenticado';
            $_SESSION['usuario_email'] = isset($usuario['email']) ? $usuario['email'] : $email;
            $_SESSION['usuario_cargo'] = isset($usuario['cargo']) ? $usuario['cargo'] : 'Membro Corporativo';
            $_SESSION['last_query'] = $executedQuery;

            header("Location: index.php?page=pages/dashboard.php");
            exit;
        } else {
            $error = 'Credenciais inválidas. Verifique seu e-mail e senha.';
        }
    }
}
?>

<section class="page-hero compact">
    <div class="container">
        <span class="eyebrow">ÁREA RESTRITA</span>
        <h1>Acesso ao Portal Corporativo</h1>
        <p>Autenticação de colaboradores, diretores e operadores do SOC.</p>
    </div>
</section>

<section class="section">
    <div class="container" style="max-width: 600px; margin: 0 auto;">
        
        <?php if (isset($_GET['logged_out'])): ?>
            <div class="success-message" style="margin-bottom: 20px;">
                <strong>Sessão encerrada com sucesso.</strong>
            </div>
        <?php endif; ?>

        <?php if (!empty($error)): ?>
            <div style="padding: 16px; margin-bottom: 20px; color: #a92020; background: #ffebeb; border: 1px solid #f5c2c2; border-radius: 5px;">
                <strong>Atenção:</strong> <?php echo htmlspecialchars($error); ?>
                <?php if (!empty($debugSqlError)): ?>
                    <div style="margin-top: 10px; font-family: monospace; font-size: 12px; background: #fff; padding: 10px; border: 1px solid #f0b0b0; border-radius: 3px; color: #781010; word-break: break-all;">
                        <strong>SQL Error:</strong> <?php echo htmlspecialchars($debugSqlError); ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="login-card" style="background: #fff; padding: 35px; border-radius: 8px; border: 1px solid #e2e8ef; box-shadow: 0 4px 15px rgba(13,32,56,.06);">
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 25px; padding-bottom: 15px; border-bottom: 1px solid #edf2f7;">
                <span class="brand-mark" style="width: 38px; height: 38px;">FS</span>
                <div>
                    <h2 style="margin: 0; font-size: 20px; color: #0d2038;">Login de Acesso</h2>
                    <small style="color: #63758c;">Informe suas credenciais corporativas</small>
                </div>
            </div>

            <form method="post" action="index.php?page=pages/login.php" class="login-form">
                <div style="margin-bottom: 18px;">
                    <label for="email" style="display: block; margin-bottom: 6px; font-weight: bold; color: #263b54; font-size: 13px;">
                        E-mail Corporativo
                    </label>
                    <input type="text" id="email" name="email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" placeholder="ex: admin@fatecseg.local" style="width: 100%; box-sizing: border-box; padding: 12px; border: 1px solid #ccd6e0; border-radius: 4px; font: inherit;" required autofocus>
                </div>

                <div style="margin-bottom: 22px;">
                    <label for="senha" style="display: block; margin-bottom: 6px; font-weight: bold; color: #263b54; font-size: 13px;">
                        Senha de Acesso
                    </label>
                    <input type="password" id="senha" name="senha" placeholder="Digite sua senha" style="width: 100%; box-sizing: border-box; padding: 12px; border: 1px solid #ccd6e0; border-radius: 4px; font: inherit;" required>
                </div>

                <button class="button" type="submit" style="width: 100%; padding: 14px; font-size: 15px; text-align: center; border-radius: 4px;">
                    Entrar no Sistema
                </button>
            </form>

            <div style="margin-top: 25px; padding-top: 15px; border-top: 1px solid #edf2f7; display: flex; justify-content: space-between; font-size: 12px; color: #718096; flex-wrap: wrap; gap: 10px;">
                <a href="index.php?page=pages/register.php" style="color: #0d64c8; font-weight: bold; text-decoration: underline;">
                    + Novo Usuário / Exemplo INSERT SQLi
                </a>
                <a href="setup_db.php" style="color: #63758c; text-decoration: underline;">
                    Resetar / Popular Banco
                </a>
            </div>
        </div>

        <!-- Painel Didático de Apoio ao Laboratório de Desenvolvimento Seguro -->
        <div style="margin-top: 30px; background: #edf4fc; border: 1px solid #c7ddf5; border-radius: 6px; padding: 20px; font-size: 13px; color: #1e3a5f;">
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px;">
                <strong style="color: #0d4a8f; font-size: 14px;"> Laboratório Didático — Desenvolvimento Seguro</strong>
                <span style="background: #0d64c8; color: #fff; font-size: 10px; padding: 2px 8px; border-radius: 12px; font-weight: bold;">SELECT SQLi LAB</span>
            </div>
            <p style="margin-bottom: 12px; line-height: 1.5;">
                O formulário acima contém uma falha de injeção de SQL proposital através da concatenação direta dos campos <code>email</code> e <code>senha</code>.
            </p>
            <div style="background: #fff; padding: 12px; border-radius: 4px; border: 1px solid #d4e3f5; margin-bottom: 12px; font-family: monospace; font-size: 11.5px; color: #334e68; overflow-x: auto;">
                SELECT * FROM usuarios WHERE email = '<span style="color:#c8410d; font-weight:bold;">$email</span>' AND senha = '<span style="color:#c8410d; font-weight:bold;">$senha</span>'
            </div>
            <details style="cursor: pointer; margin-top: 8px;">
                <summary style="font-weight: bold; color: #0d64c8;">Ver exemplos de payloads para teste (SQL Injection Bypass)</summary>
                <div style="margin-top: 10px; padding: 10px; background: #fff; border-radius: 4px; border: 1px solid #d4e3f5; font-size: 12px;">
                    <ul style="margin: 0; padding-left: 18px; line-height: 1.7;">
                        <li><strong>Auth Bypass Geral:</strong> No e-mail digite <code>' OR '1'='1</code> e qualquer senha.</li>
                        <li><strong>Bypass como Admin:</strong> No e-mail digite <code>admin@fatecseg.local' -- </code> e qualquer senha.</li>
                        <li><strong>Bypass com Comentário Hash:</strong> No e-mail digite <code>admin@fatecseg.local' #</code> e qualquer senha.</li>
                        <li><strong>Login Legítimo:</strong> E-mail <code>admin@fatecseg.local</code> | Senha: <code>admin123</code></li>
                        <li><strong>Exemplo de INSERT:</strong> Acesse o formulário de <a href="index.php?page=pages/register.php" style="color:#0d64c8; font-weight:bold;">Cadastro de Usuário</a>.</li>
                    </ul>
                </div>
            </details>
        </div>

    </div>
</section>
