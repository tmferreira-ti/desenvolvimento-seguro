(function () {
    var toggle = document.querySelector('.menu-toggle');
    var menu = document.querySelector('.menu');
    if (toggle && menu) {
        toggle.onclick = function () {
            menu.classList.toggle('open');
        };
    }
}());
